package fr.minenorth.portes.door;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Lien avec le mod MineNorth Police, par réflexion : le mod Portes compile et fonctionne sans lui.
 * - les portes POLICE s'ouvrent pour les policiers enregistrés sur la tablette ;
 * - pendant une perquisition acceptée, les portes personnelles du citoyen s'ouvrent pour la police.
 */
public final class PoliceCompat {
    private PoliceCompat() {}

    private static Method isPolice, canSearch;

    private static boolean loaded() { return ModList.get().isLoaded("minenorthpolice"); }

    public static boolean isPolice(ServerPlayer p) {
        if (!loaded()) return false;
        try {
            if (isPolice == null) isPolice = Class.forName("fr.minenorth.police.api.PoliceApi").getMethod("isPolice", ServerPlayer.class);
            return Boolean.TRUE.equals(isPolice.invoke(null, p));
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean canSearch(ServerPlayer officer, UUID owner) {
        if (owner == null || !loaded()) return false;
        try {
            if (canSearch == null) canSearch = Class.forName("fr.minenorth.police.api.PoliceApi").getMethod("canSearch", ServerPlayer.class, UUID.class);
            return Boolean.TRUE.equals(canSearch.invoke(null, officer, owner));
        } catch (Throwable t) {
            return false;
        }
    }
}
