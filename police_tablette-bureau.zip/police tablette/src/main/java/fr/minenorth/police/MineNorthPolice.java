package fr.minenorth.police;

import fr.minenorth.police.block.ModBlocks;
import fr.minenorth.police.config.PoliceConfig;
import fr.minenorth.police.item.ModItems;
import fr.minenorth.police.network.ModNetwork;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MineNorthPolice.MOD_ID)
public class MineNorthPolice {
    public static final String MOD_ID = "minenorthpolice";

    public MineNorthPolice() {
        PoliceConfig.load();
        ModNetwork.register();
        ModBlocks.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModItems.register(FMLJavaModLoadingContext.get().getModEventBus());
    }
}
